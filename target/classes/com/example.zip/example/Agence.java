
import com.example.Administration.AdministrationVoiture;
import com.example.dao.*;
import com.example.vehicules.Vehicule;
import com.example.vehicules.Voiture;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Scanner;
import com.example.Administration.*;

/**
 *
 * @author rachad
 */
public class Agence {

    static LinkedList<Vehicule> liste;

    static void VoletVoiture() throws SQLException{
            AdministrationVoiture admin= new AdministrationVoiture();
            Scanner sc = new Scanner(System.in);
            System.out.println("Veuiller Choisir la tâches");
            System.out.println("1-Ajouter une nouvelle voiture");
            System.out.println("2-Suprimer une voiture");
            System.out.println("3-Chercher une voiture par Modele");
            System.out.println("4-Chercher une voiture par Reference");
            System.out.println("5-Chercher une voiture par Marque");
            System.out.println("6-Chercher une voiture par Couleur");
            int task = sc.nextInt();
             if(task==1){
                 System.out.println("Veuiller Saisir le modele de la voiture");
                 String modele = sc.next();
                 System.out.println("Veuiller Saisir la reference de la voiture");
                 String ref = sc.next();
                 System.out.println("Veuiller Saisir la couleur de la voiture");
                 String couleur = sc.next();
                 System.out.println("Veuiller Saisir la marque de la voiture");
                 String marque = sc.next();
                 Voiture v= new Voiture(ref,modele,marque,couleur);
                 admin.AjouterVehicule(v);}
            if(task == 2) {
                
            }
             else if(task==3){
                 System.out.println("Veuiller Saisir le modele de la voiture");
                 String modele = sc.next();
                 LinkedList<Voiture> voitures=admin.RechercheParModele(modele);
                 for (Voiture v:voitures)
                     System.out.println(v);}
    }

    static void VoletCamionnette() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from
                                                                       // nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void VoletMinibus() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from
                                                                       // nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void main(String args[]) throws SQLException {

        liste = new LinkedList<Vehicule>(); // ca doit etre remplacée par la BD

        Scanner sc = new Scanner(System.in);
        System.out.println("Veuiller Choisir le type de Vehicule");
        System.out.println("1-Voitures");
        System.out.println("2-Camionnette");
        System.out.println("3-Mini-Bus");
        int option = sc.nextInt();
        if (option == 1) {
            VoletVoiture();
        } else if (option == 2) {
            VoletCamionnette();
        } else if (option == 3) {
            VoletMinibus();
        } else
            System.out.println("option invalide");
    }

}
