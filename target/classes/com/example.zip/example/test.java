import java.util.LinkedList;

import com.example.vehicules.Vehicule;

public class test {
    LinkedList<Vehicule> list;    
}
